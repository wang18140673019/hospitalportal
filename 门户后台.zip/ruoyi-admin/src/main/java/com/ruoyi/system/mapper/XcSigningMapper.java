package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.XcSigning;

/**
 * 【请填写功能名称】Mapper接口
 * 
 * @author ruoyi
 * @date 2021-01-28
 */
public interface XcSigningMapper 
{
    /**
     * 查询【请填写功能名称】
     * 
     * @param signingId 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */
    public XcSigning selectXcSigningById(Integer signingId);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param xcSigning 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<XcSigning> selectXcSigningList(XcSigning xcSigning);

    /**
     * 新增【请填写功能名称】
     * 
     * @param xcSigning 【请填写功能名称】
     * @return 结果
     */
    public int insertXcSigning(XcSigning xcSigning);

    /**
     * 修改【请填写功能名称】
     * 
     * @param xcSigning 【请填写功能名称】
     * @return 结果
     */
    public int updateXcSigning(XcSigning xcSigning);

    /**
     * 删除【请填写功能名称】
     * 
     * @param signingId 【请填写功能名称】ID
     * @return 结果
     */
    public int deleteXcSigningById(Integer signingId);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param signingIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteXcSigningByIds(String[] signingIds);
}
