package com.ruoyi.system.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.arronlong.httpclientutil.HttpClientUtil;
import com.arronlong.httpclientutil.common.HttpConfig;
import com.arronlong.httpclientutil.exception.HttpProcessException;
import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.utils.ShiroUtils;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.util.EntityUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.Formula;
import com.ruoyi.system.service.IFormulaService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;
import org.springframework.web.multipart.MultipartFile;

import javax.net.ssl.SSLContext;

/**
 * 分子式Controller
 *
 * @author ruoyi
 * @date 2020-11-23
 */
@Controller
@RequestMapping("/system/formula")
public class FormulaController extends BaseController {
    private String prefix = "system/formula";

    @Autowired
    private IFormulaService formulaService;

    @RequiresPermissions("system:formula:view")
    @GetMapping()
    public String formula() {
        return prefix + "/formula";
    }

    /**
     * 查询分子式列表
     */
    @RequiresPermissions("system:formula:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Formula formula) {
        startPage();
        List<Formula> list = formulaService.selectFormulaList(formula);
        return getDataTable(list);
    }

    /**
     * 导出分子式列表
     */
    @RequiresPermissions("system:formula:export")
    @Log(title = "分子式", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Formula formula) {
        List<Formula> list = formulaService.selectFormulaList(formula);
        ExcelUtil<Formula> util = new ExcelUtil<Formula>(Formula.class);
        return util.exportExcel(list, "formula");
    }

    /**
     * 新增分子式
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存分子式
     */
     @RequiresPermissions("system:formula:add")
    @Log(title = "分子式", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Formula formula) {
        return toAjax(formulaService.insertFormula(formula));
    }

    /**
     * 修改分子式
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap) {
        Formula formula = formulaService.selectFormulaById(id);
        mmap.put("formula", formula);
        return prefix + "/edit";
    }

    /**
     * 修改保存分子式
     */
      @RequiresPermissions("system:formula:edit")
    @Log(title = "分子式", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Formula formula) {
        return toAjax(formulaService.updateFormula(formula));
    }

    /**
     * 删除分子式
     */
    @RequiresPermissions("system:formula:remove")
    @Log(title = "分子式", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(formulaService.deleteFormulaByIds(ids));
    }

    @GetMapping("/importTemplate")
    @ResponseBody
    public AjaxResult importTemplate() {
        ExcelUtil<Formula> util = new ExcelUtil<Formula>(Formula.class);
        return util.importTemplateExcel("分子式");
    }


    @PostMapping("/importData")
    @ResponseBody
    public AjaxResult importData(MultipartFile file, boolean updateSupport) throws Exception {
        ExcelUtil<Formula> util = new ExcelUtil<Formula>(Formula.class);
        List<Formula> formulaList = util.importExcel(file.getInputStream());
        getFormulaReslt(formulaList);



        return AjaxResult.success("导入完成");
    }


    public String getFormulaReslt(List<Formula> formulaList) {
        ThreadPoolExecutor executor = new ThreadPoolExecutor(10, 10, 200, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<Runnable>(10000));


        for (int i = 0; i < formulaList.size(); i++) {
            Formula formula = formulaList.get(i);
            executor.execute(new Runnable() {
                @Override
                public void run() {
                    Map resultMap = executeComparison(formula);
                    if (resultMap != null) {
                        JSONObject result = (JSONObject) resultMap.get("response");
                        if (result != null && result.get("hitcount") != null) {
                            int hitcount = (Integer) result.get("hitcount");
                            if (hitcount > 0) {
                                formula.setComparisonresult("1");
                            } else {
                                formula.setComparisonresult("0");
                            }

                            formulaService.insertFormula(formula);
                        }

                    }

                }
            });

        }
        executor.shutdown();
        return "";
    }

    public Map executeComparison(Formula formula) {

        String urlpara = "{\"query\":{\"type\":\"formula\",\"parameter\":[{\"name\":\"FormulaQuery\",\"string\":\"#{CO2}\"},{\"name\":\"UseCache\",\"bool\":true},{\"name\":\"SearchTimeMsec\",\"num\":5000},{\"name\":\"SearchMaxRecords\",\"num\":100000},{\"name\":\"allowotherelements\",\"bool\":false}]}}";
        urlpara = urlpara.replace("#{CO2}", formula.getIdentity());
        try {
            urlpara = URLEncoder.encode(urlpara, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 1.生成一个请求
        HttpPost httpPost = new HttpPost("https://pubchem.ncbi.nlm.nih.gov/unified_search/structure_search.cgi?format=json&queryblob=" + urlpara);

        // 2.配置请求属性
        // 2.1 设置请求超时时间
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(60 * 1000).setConnectTimeout(60 * 1000)
                .build();
        httpPost.setConfig(requestConfig);
        // 2.2 设置数据传输格式-json
        httpPost.addHeader("Content-Type", "application/json");
        // 2.3 设置请求实体，封装了请求参数
        httpPost.setEntity(null);

        // 3.发起请求，获取响应信息
        // 3.1 创建httpClient
        CloseableHttpClient httpClient = HttpClients.createDefault();
        CloseableHttpResponse response = null;

        // 3.3 发起请求，获取响应
        try {
            response = httpClient.execute(httpPost, new BasicHttpContext());
        } catch (ClientProtocolException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        if (response.getStatusLine().getStatusCode() != 200) {

            System.out.println(
                    "request url failed, http code=" + response.getStatusLine().getStatusCode() + ", url=");
            throw new RuntimeException("请求出错StatusCode：" + response.getStatusLine().getStatusCode());
        }
        // 有返回值不代表你的逻辑对了，只是post没有报错而已
        String jsonstr = "";
        try {
            jsonstr = EntityUtils.toString(response.getEntity());
            return (Map) JSON.parse(jsonstr);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
