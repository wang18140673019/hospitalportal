package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.XcSigningMapper;
import com.ruoyi.system.domain.XcSigning;
import com.ruoyi.system.service.IXcSigningService;
import com.ruoyi.common.core.text.Convert;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2021-01-28
 */
@Service
public class XcSigningServiceImpl implements IXcSigningService 
{
    @Autowired
    private XcSigningMapper xcSigningMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param signingId 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */
    @Override
    public XcSigning selectXcSigningById(Integer signingId)
    {
        return xcSigningMapper.selectXcSigningById(signingId);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param xcSigning 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<XcSigning> selectXcSigningList(XcSigning xcSigning)
    {
        return xcSigningMapper.selectXcSigningList(xcSigning);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param xcSigning 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertXcSigning(XcSigning xcSigning)
    {
        xcSigning.setCreateTime(DateUtils.getNowDate());
        return xcSigningMapper.insertXcSigning(xcSigning);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param xcSigning 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateXcSigning(XcSigning xcSigning)
    {
        xcSigning.setUpdateTime(DateUtils.getNowDate());
        return xcSigningMapper.updateXcSigning(xcSigning);
    }

    /**
     * 删除【请填写功能名称】对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteXcSigningByIds(String ids)
    {
        return xcSigningMapper.deleteXcSigningByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param signingId 【请填写功能名称】ID
     * @return 结果
     */
    @Override
    public int deleteXcSigningById(Integer signingId)
    {
        return xcSigningMapper.deleteXcSigningById(signingId);
    }
}
