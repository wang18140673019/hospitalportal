package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.XcFamilyMember;

/**
 * 【请填写功能名称】Mapper接口
 * 
 * @author ruoyi
 * @date 2021-01-28
 */
public interface XcFamilyMemberMapper 
{
    /**
     * 查询【请填写功能名称】
     * 
     * @param familyId 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */
    public XcFamilyMember selectXcFamilyMemberById(Integer familyId);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param xcFamilyMember 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<XcFamilyMember> selectXcFamilyMemberList(XcFamilyMember xcFamilyMember);

    /**
     * 新增【请填写功能名称】
     * 
     * @param xcFamilyMember 【请填写功能名称】
     * @return 结果
     */
    public int insertXcFamilyMember(XcFamilyMember xcFamilyMember);

    /**
     * 修改【请填写功能名称】
     * 
     * @param xcFamilyMember 【请填写功能名称】
     * @return 结果
     */
    public int updateXcFamilyMember(XcFamilyMember xcFamilyMember);

    /**
     * 删除【请填写功能名称】
     * 
     * @param familyId 【请填写功能名称】ID
     * @return 结果
     */
    public int deleteXcFamilyMemberById(Integer familyId);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param familyIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteXcFamilyMemberByIds(String[] familyIds);
}
