package com.ruoyi.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.FormulaMapper;
import com.ruoyi.system.domain.Formula;
import com.ruoyi.system.service.IFormulaService;
import com.ruoyi.common.core.text.Convert;

/**
 * 分子式Service业务层处理
 * 
 * @author ruoyi
 * @date 2020-11-23
 */
@Service
public class FormulaServiceImpl implements IFormulaService 
{
    @Autowired
    private FormulaMapper formulaMapper;

    /**
     * 查询分子式
     * 
     * @param id 分子式ID
     * @return 分子式
     */
    @Override
    public Formula selectFormulaById(Long id)
    {
        return formulaMapper.selectFormulaById(id);
    }

    /**
     * 查询分子式列表
     * 
     * @param formula 分子式
     * @return 分子式
     */
    @Override
    public List<Formula> selectFormulaList(Formula formula)
    {
        return formulaMapper.selectFormulaList(formula);
    }

    /**
     * 新增分子式
     * 
     * @param formula 分子式
     * @return 结果
     */
    @Override
    public int insertFormula(Formula formula)
    {
        return formulaMapper.insertFormula(formula);
    }

    /**
     * 修改分子式
     * 
     * @param formula 分子式
     * @return 结果
     */
    @Override
    public int updateFormula(Formula formula)
    {
        return formulaMapper.updateFormula(formula);
    }

    /**
     * 删除分子式对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteFormulaByIds(String ids)
    {
        return formulaMapper.deleteFormulaByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除分子式信息
     * 
     * @param id 分子式ID
     * @return 结果
     */
    @Override
    public int deleteFormulaById(Long id)
    {
        return formulaMapper.deleteFormulaById(id);
    }
}
