package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 【请填写功能名称】对象 xc_signing
 * 
 * @author ruoyi
 * @date 2021-01-28
 */
public class XcSigning extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long signingId;

    /** 家庭签约临时编号 */
    @Excel(name = "家庭签约临时编号")
    private String familySn;

    /** 户籍性质：城市/农村 */
    @Excel(name = "户籍性质：城市/农村")
    private String residenceType;

    /** 户主:家庭成员family_member的family_id */
    @Excel(name = "户主:家庭成员family_member的family_id")
    private Long householderId;

    /** 户主的身份证号码 */
    @Excel(name = "户主的身份证号码")
    private String householderCardId;

    /** 户口簿户号 */
    @Excel(name = "户口簿户号")
    private String householdNum;

    /** 户主的名字 */
    @Excel(name = "户主的名字")
    private String householder;

    /** 建档类型：建档立卡贫困户/非贫困户 */
    @Excel(name = "建档类型：建档立卡贫困户/非贫困户")
    private String fileType;

    /** $column.columnComment */
    @Excel(name = "建档类型：建档立卡贫困户/非贫困户")
    private String typeOther;

    /** $column.columnComment */
    @Excel(name = "建档类型：建档立卡贫困户/非贫困户")
    private String provinceName;

    /** $column.columnComment */
    @Excel(name = "建档类型：建档立卡贫困户/非贫困户")
    private String cityName;

    /** $column.columnComment */
    @Excel(name = "建档类型：建档立卡贫困户/非贫困户")
    private String areaName;

    /** 镇 */
    @Excel(name = "镇")
    private String streetName;

    /** $column.columnComment */
    @Excel(name = "镇")
    private String villageName;

    /** $column.columnComment */
    @Excel(name = "镇")
    private Long provinceId;

    /** $column.columnComment */
    @Excel(name = "镇")
    private Long cityId;

    /** $column.columnComment */
    @Excel(name = "镇")
    private Long areaId;

    /** 镇乡id */
    @Excel(name = "镇乡id")
    private Long streetId;

    /** 村id */
    @Excel(name = "村id")
    private Long villageId;

    /** 家庭详细地址 */
    @Excel(name = "家庭详细地址")
    private String familyAddr;

    /** 门牌号 */
    @Excel(name = "门牌号")
    private Long houseNum;

    /** $column.columnComment */
    @Excel(name = "门牌号")
    private Long shopId;

    /** 医生团队id */
    @Excel(name = "医生团队id")
    private Long teamId;

    /** 录入的医生的id */
    @Excel(name = "录入的医生的id")
    private Long workerId;

    /** 当时录入签约记录的医生名字（只做记录用） */
    @Excel(name = "当时录入签约记录的医生名字", readConverterExp = "只=做记录用")
    private String doctorName;

    /** 所在乡村id */
    @Excel(name = "所在乡村id")
    private Long countrysideId;

    /** $column.columnComment */
    @Excel(name = "所在乡村id")
    private String countrysideName;

    /** 家庭医生id(队长) */
    @Excel(name = "家庭医生id(队长)")
    private Long familyDoctorId;

    /** 家庭医生（队长）名字 */
    @Excel(name = "家庭医生", readConverterExp = "队=长")
    private String familyDoctorName;

    /** 责任医生id */
    @Excel(name = "责任医生id")
    private Long countrysideDoctorId;

    /** 责任医生名字 */
    @Excel(name = "责任医生名字")
    private String countrysideDoctorName;

    /** 是否正常 */
    @Excel(name = "是否正常")
    private Integer closed;

    /** 50 */
    @Excel(name = "50")
    private String updateIp;

    /** 旧的团队（如果有新的团队替换） */
    @Excel(name = "旧的团队", readConverterExp = "如=果有新的团队替换")
    private Long oldTeamId;

    /** 旧的家庭医生（如果家庭医生被替换） */
    @Excel(name = "旧的家庭医生", readConverterExp = "如=果家庭医生被替换")
    private Long oldFamilyDoctorId;

    /** 旧的责任村医id(如果有新的责任村医过来顶替) */
    @Excel(name = "旧的责任村医id(如果有新的责任村医过来顶替)")
    private Long oldCountrysideDoctorId;

    /** -1,签约过期，0等待签约，1正常服务中 */
    @Excel(name = "-1,签约过期，0等待签约，1正常服务中")
    private Integer signingStatus;

    /** 签约服务开始时间 */
    @Excel(name = "签约服务开始时间")
    private Long serviceStartTime;

    /** 签约服务结束时间 */
    @Excel(name = "签约服务结束时间")
    private Long serviceEndTime;

    public void setSigningId(Long signingId)
    {
        this.signingId = signingId;
    }

    public Long getSigningId()
    {
        return signingId;
    }
    public void setFamilySn(String familySn) 
    {
        this.familySn = familySn;
    }

    public String getFamilySn() 
    {
        return familySn;
    }
    public void setResidenceType(String residenceType) 
    {
        this.residenceType = residenceType;
    }

    public String getResidenceType() 
    {
        return residenceType;
    }
    public void setHouseholderId(Long householderId) 
    {
        this.householderId = householderId;
    }

    public Long getHouseholderId() 
    {
        return householderId;
    }
    public void setHouseholderCardId(String householderCardId) 
    {
        this.householderCardId = householderCardId;
    }

    public String getHouseholderCardId() 
    {
        return householderCardId;
    }
    public void setHouseholdNum(String householdNum) 
    {
        this.householdNum = householdNum;
    }

    public String getHouseholdNum() 
    {
        return householdNum;
    }
    public void setHouseholder(String householder) 
    {
        this.householder = householder;
    }

    public String getHouseholder() 
    {
        return householder;
    }
    public void setFileType(String fileType) 
    {
        this.fileType = fileType;
    }

    public String getFileType() 
    {
        return fileType;
    }
    public void setTypeOther(String typeOther) 
    {
        this.typeOther = typeOther;
    }

    public String getTypeOther() 
    {
        return typeOther;
    }
    public void setProvinceName(String provinceName) 
    {
        this.provinceName = provinceName;
    }

    public String getProvinceName() 
    {
        return provinceName;
    }
    public void setCityName(String cityName) 
    {
        this.cityName = cityName;
    }

    public String getCityName() 
    {
        return cityName;
    }
    public void setAreaName(String areaName) 
    {
        this.areaName = areaName;
    }

    public String getAreaName() 
    {
        return areaName;
    }
    public void setStreetName(String streetName) 
    {
        this.streetName = streetName;
    }

    public String getStreetName() 
    {
        return streetName;
    }
    public void setVillageName(String villageName) 
    {
        this.villageName = villageName;
    }

    public String getVillageName() 
    {
        return villageName;
    }
    public void setProvinceId(Long provinceId) 
    {
        this.provinceId = provinceId;
    }

    public Long getProvinceId() 
    {
        return provinceId;
    }
    public void setCityId(Long cityId) 
    {
        this.cityId = cityId;
    }

    public Long getCityId() 
    {
        return cityId;
    }
    public void setAreaId(Long areaId) 
    {
        this.areaId = areaId;
    }

    public Long getAreaId() 
    {
        return areaId;
    }
    public void setStreetId(Long streetId) 
    {
        this.streetId = streetId;
    }

    public Long getStreetId() 
    {
        return streetId;
    }
    public void setVillageId(Long villageId) 
    {
        this.villageId = villageId;
    }

    public Long getVillageId() 
    {
        return villageId;
    }
    public void setFamilyAddr(String familyAddr) 
    {
        this.familyAddr = familyAddr;
    }

    public String getFamilyAddr() 
    {
        return familyAddr;
    }
    public void setHouseNum(Long houseNum) 
    {
        this.houseNum = houseNum;
    }

    public Long getHouseNum() 
    {
        return houseNum;
    }
    public void setShopId(Long shopId) 
    {
        this.shopId = shopId;
    }

    public Long getShopId() 
    {
        return shopId;
    }
    public void setTeamId(Long teamId) 
    {
        this.teamId = teamId;
    }

    public Long getTeamId() 
    {
        return teamId;
    }
    public void setWorkerId(Long workerId) 
    {
        this.workerId = workerId;
    }

    public Long getWorkerId() 
    {
        return workerId;
    }
    public void setDoctorName(String doctorName) 
    {
        this.doctorName = doctorName;
    }

    public String getDoctorName() 
    {
        return doctorName;
    }
    public void setCountrysideId(Long countrysideId) 
    {
        this.countrysideId = countrysideId;
    }

    public Long getCountrysideId() 
    {
        return countrysideId;
    }
    public void setCountrysideName(String countrysideName) 
    {
        this.countrysideName = countrysideName;
    }

    public String getCountrysideName() 
    {
        return countrysideName;
    }
    public void setFamilyDoctorId(Long familyDoctorId) 
    {
        this.familyDoctorId = familyDoctorId;
    }

    public Long getFamilyDoctorId() 
    {
        return familyDoctorId;
    }
    public void setFamilyDoctorName(String familyDoctorName) 
    {
        this.familyDoctorName = familyDoctorName;
    }

    public String getFamilyDoctorName() 
    {
        return familyDoctorName;
    }
    public void setCountrysideDoctorId(Long countrysideDoctorId) 
    {
        this.countrysideDoctorId = countrysideDoctorId;
    }

    public Long getCountrysideDoctorId() 
    {
        return countrysideDoctorId;
    }
    public void setCountrysideDoctorName(String countrysideDoctorName) 
    {
        this.countrysideDoctorName = countrysideDoctorName;
    }

    public String getCountrysideDoctorName() 
    {
        return countrysideDoctorName;
    }
    public void setClosed(Integer closed) 
    {
        this.closed = closed;
    }

    public Integer getClosed() 
    {
        return closed;
    }
    public void setUpdateIp(String updateIp) 
    {
        this.updateIp = updateIp;
    }

    public String getUpdateIp() 
    {
        return updateIp;
    }
    public void setOldTeamId(Long oldTeamId) 
    {
        this.oldTeamId = oldTeamId;
    }

    public Long getOldTeamId() 
    {
        return oldTeamId;
    }
    public void setOldFamilyDoctorId(Long oldFamilyDoctorId) 
    {
        this.oldFamilyDoctorId = oldFamilyDoctorId;
    }

    public Long getOldFamilyDoctorId() 
    {
        return oldFamilyDoctorId;
    }
    public void setOldCountrysideDoctorId(Long oldCountrysideDoctorId) 
    {
        this.oldCountrysideDoctorId = oldCountrysideDoctorId;
    }

    public Long getOldCountrysideDoctorId() 
    {
        return oldCountrysideDoctorId;
    }
    public void setSigningStatus(Integer signingStatus) 
    {
        this.signingStatus = signingStatus;
    }

    public Integer getSigningStatus() 
    {
        return signingStatus;
    }
    public void setServiceStartTime(Long serviceStartTime) 
    {
        this.serviceStartTime = serviceStartTime;
    }

    public Long getServiceStartTime() 
    {
        return serviceStartTime;
    }
    public void setServiceEndTime(Long serviceEndTime) 
    {
        this.serviceEndTime = serviceEndTime;
    }

    public Long getServiceEndTime() 
    {
        return serviceEndTime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("signingId", getSigningId())
            .append("familySn", getFamilySn())
            .append("residenceType", getResidenceType())
            .append("householderId", getHouseholderId())
            .append("householderCardId", getHouseholderCardId())
            .append("householdNum", getHouseholdNum())
            .append("householder", getHouseholder())
            .append("fileType", getFileType())
            .append("typeOther", getTypeOther())
            .append("provinceName", getProvinceName())
            .append("cityName", getCityName())
            .append("areaName", getAreaName())
            .append("streetName", getStreetName())
            .append("villageName", getVillageName())
            .append("provinceId", getProvinceId())
            .append("cityId", getCityId())
            .append("areaId", getAreaId())
            .append("streetId", getStreetId())
            .append("villageId", getVillageId())
            .append("familyAddr", getFamilyAddr())
            .append("houseNum", getHouseNum())
            .append("shopId", getShopId())
            .append("teamId", getTeamId())
            .append("workerId", getWorkerId())
            .append("doctorName", getDoctorName())
            .append("countrysideId", getCountrysideId())
            .append("countrysideName", getCountrysideName())
            .append("familyDoctorId", getFamilyDoctorId())
            .append("familyDoctorName", getFamilyDoctorName())
            .append("countrysideDoctorId", getCountrysideDoctorId())
            .append("countrysideDoctorName", getCountrysideDoctorName())
            .append("closed", getClosed())
            .append("createTime", getCreateTime())
            .append("updateTime", getUpdateTime())
            .append("updateIp", getUpdateIp())
            .append("oldTeamId", getOldTeamId())
            .append("oldFamilyDoctorId", getOldFamilyDoctorId())
            .append("oldCountrysideDoctorId", getOldCountrysideDoctorId())
            .append("signingStatus", getSigningStatus())
            .append("serviceStartTime", getServiceStartTime())
            .append("serviceEndTime", getServiceEndTime())
            .toString();
    }
}
