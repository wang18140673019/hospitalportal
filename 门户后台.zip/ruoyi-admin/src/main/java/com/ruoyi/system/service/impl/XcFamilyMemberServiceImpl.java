package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.XcFamilyMemberMapper;
import com.ruoyi.system.domain.XcFamilyMember;
import com.ruoyi.system.service.IXcFamilyMemberService;
import com.ruoyi.common.core.text.Convert;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2021-01-28
 */
@Service
public class XcFamilyMemberServiceImpl implements IXcFamilyMemberService 
{
    @Autowired
    private XcFamilyMemberMapper xcFamilyMemberMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param familyId 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */
    @Override
    public XcFamilyMember selectXcFamilyMemberById(Integer familyId)
    {
        return xcFamilyMemberMapper.selectXcFamilyMemberById(familyId);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param xcFamilyMember 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<XcFamilyMember> selectXcFamilyMemberList(XcFamilyMember xcFamilyMember)
    {
        return xcFamilyMemberMapper.selectXcFamilyMemberList(xcFamilyMember);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param xcFamilyMember 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertXcFamilyMember(XcFamilyMember xcFamilyMember)
    {
        xcFamilyMember.setCreateTime(DateUtils.getNowDate());
        return xcFamilyMemberMapper.insertXcFamilyMember(xcFamilyMember);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param xcFamilyMember 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateXcFamilyMember(XcFamilyMember xcFamilyMember)
    {
        return xcFamilyMemberMapper.updateXcFamilyMember(xcFamilyMember);
    }

    /**
     * 删除【请填写功能名称】对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteXcFamilyMemberByIds(String ids)
    {
        return xcFamilyMemberMapper.deleteXcFamilyMemberByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param familyId 【请填写功能名称】ID
     * @return 结果
     */
    @Override
    public int deleteXcFamilyMemberById(Integer familyId)
    {
        return xcFamilyMemberMapper.deleteXcFamilyMemberById(familyId);
    }
}
