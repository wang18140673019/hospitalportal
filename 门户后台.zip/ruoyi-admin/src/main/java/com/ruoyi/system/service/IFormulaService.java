package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.Formula;

/**
 * 分子式Service接口
 * 
 * @author ruoyi
 * @date 2020-11-23
 */
public interface IFormulaService 
{
    /**
     * 查询分子式
     * 
     * @param id 分子式ID
     * @return 分子式
     */
    public Formula selectFormulaById(Long id);

    /**
     * 查询分子式列表
     * 
     * @param formula 分子式
     * @return 分子式集合
     */
    public List<Formula> selectFormulaList(Formula formula);

    /**
     * 新增分子式
     * 
     * @param formula 分子式
     * @return 结果
     */
    public int insertFormula(Formula formula);

    /**
     * 修改分子式
     * 
     * @param formula 分子式
     * @return 结果
     */
    public int updateFormula(Formula formula);

    /**
     * 批量删除分子式
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteFormulaByIds(String ids);

    /**
     * 删除分子式信息
     * 
     * @param id 分子式ID
     * @return 结果
     */
    public int deleteFormulaById(Long id);
}
