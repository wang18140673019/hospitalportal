package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 分子式对象 formula
 * 
 * @author ruoyi
 * @date 2020-11-23
 */
public class Formula extends BaseEntity
{
    private static final long serialVersionUID = 1L;
    /** row ID */
    @Excel(name = "row ID")
    private Long id;

    /** row m/z */
    @Excel(name = "row m/z")
    private String mz;


    /** row retention time */
    @Excel(name = "row retention time")
    private String retentiontime;

    /** row identity (main ID) */
    @Excel(name = "row identity (main ID)")
    private String identity;

    /** result */
    @Excel(name = "result")
    private String comparisonresult;

    public void setIdentity(String identity) 
    {
        this.identity = identity;
    }

    public String getIdentity() 
    {
        return identity;
    }
    public void setRetentiontime(String retentiontime) 
    {
        this.retentiontime = retentiontime;
    }

    public String getRetentiontime() 
    {
        return retentiontime;
    }
    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setMz(String mz) 
    {
        this.mz = mz;
    }

    public String getMz() 
    {
        return mz;
    }
    public void setComparisonresult(String comparisonresult) 
    {
        this.comparisonresult = comparisonresult;
    }

    public String getComparisonresult() 
    {
        return comparisonresult;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("identity", getIdentity())
            .append("retentiontime", getRetentiontime())
            .append("id", getId())
            .append("mz", getMz())
            .append("comparisonresult", getComparisonresult())
            .toString();
    }
}
