package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 【请填写功能名称】对象 xc_family_member
 * 
 * @author ruoyi
 * @date 2021-01-28
 */
public class XcFamilyMember extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Integer familyId;

    /** 户号 */
    @Excel(name = "户号")
    private String householdNum;

    /** 关联注册用户 */
    @Excel(name = "关联注册用户")
    private Long userId;

    /** 家庭健康档案编号 */
    @Excel(name = "家庭健康档案编号")
    private String familySn;

    /** 家庭档案编号 */
    @Excel(name = "家庭档案编号")
    private String familyHealthNum;

    /** 个人健康档案编号 */
    @Excel(name = "个人健康档案编号")
    private String personalHealthNum;

    /** 家庭户属性：一般户，低保户，五保户，贫困户，特困户，烈家属，其他 */
    @Excel(name = "家庭户属性：一般户，低保户，五保户，贫困户，特困户，烈家属，其他")
    private String familyType;

    /** 居住类型：户籍，非户籍 */
    @Excel(name = "居住类型：户籍，非户籍")
    private String liveType;

    /** 居住地 */
    @Excel(name = "居住地")
    private String familyAddr;

    /** 先居住地 */
    @Excel(name = "先居住地")
    private String persentAddr;

    /** 签约id */
    @Excel(name = "签约id")
    private Long signingId;

    /** 这里用于导出数据，主要还是用家庭的shop_id */
    @Excel(name = "这里用于导出数据，主要还是用家庭的shop_id")
    private Long shopId;

    /** 当时的家庭医生、责任医生所在的团队id */
    @Excel(name = "当时的家庭医生、责任医生所在的团队id")
    private Long teamId;

    /** 填写资料的医生id */
    @Excel(name = "填写资料的医生id")
    private Long workerId;

    /** $column.columnComment */
    @Excel(name = "填写资料的医生id")
    private String doctorName;

    /** 村名字 */
    @Excel(name = "村名字")
    private String villageName;

    /** $column.columnComment */
    @Excel(name = "村名字")
    private Long villageId;

    /** 街道名字 */
    @Excel(name = "街道名字")
    private String streetName;

    /** $column.columnComment */
    @Excel(name = "街道名字")
    private Long streetId;

    /** 区域名字 */
    @Excel(name = "区域名字")
    private String areaName;

    /** $column.columnComment */
    @Excel(name = "区域名字")
    private Long areaId;

    /** 城市名字 */
    @Excel(name = "城市名字")
    private String cityName;

    /** $column.columnComment */
    @Excel(name = "城市名字")
    private Long cityId;

    /** 省名字 */
    @Excel(name = "省名字")
    private String provinceName;

    /** $column.columnComment */
    @Excel(name = "省名字")
    private Long provinceId;

    /** $column.columnComment */
    @Excel(name = "省名字")
    private Long countrysideId;

    /** $column.columnComment */
    @Excel(name = "省名字")
    private String countrysideName;

    /** 家庭医生（队长的）角色id */
    @Excel(name = "家庭医生", readConverterExp = "队=长的")
    private Long familyDoctorRoleId;

    /** 家庭医生的角色名字 */
    @Excel(name = "家庭医生的角色名字")
    private String familyDoctorRoleName;

    /** 家庭医生id */
    @Excel(name = "家庭医生id")
    private Long familyDoctorId;

    /** 家庭医生名字 */
    @Excel(name = "家庭医生名字")
    private String familyDoctorName;

    /** $column.columnComment */
    @Excel(name = "家庭医生名字")
    private Long countrysideDoctorRoleId;

    /** 责任医生的角色名字 */
    @Excel(name = "责任医生的角色名字")
    private String countrysideDoctorRoleName;

    /** 责任医生id */
    @Excel(name = "责任医生id")
    private Long countrysideDoctorId;

    /** 责任医生名字 */
    @Excel(name = "责任医生名字")
    private String countrysideDoctorName;

    /** 户主名字 */
    @Excel(name = "户主名字")
    private String headerName;

    /** 成员名字 */
    @Excel(name = "成员名字")
    private String userName;

    /** $column.columnComment */
    @Excel(name = "成员名字")
    private String sex;

    /** 年龄 */
    @Excel(name = "年龄")
    private Long age;

    /** 生日 */
    @Excel(name = "生日")
    private String birthday;

    /** 医疗费用支付方式 */
    @Excel(name = "医疗费用支付方式")
    private String medicalPaytype;

    /** 未婚，已婚，初婚，再婚，丧偶，离婚，未说明的婚姻状态（0未婚，1已婚，2其他 已废弃） */
    @Excel(name = "未婚，已婚，初婚，再婚，丧偶，离婚，未说明的婚姻状态", readConverterExp = "0=未婚，1已婚，2其他,已=废弃")
    private String maritalStatus;

    /** 关系表：relation的id */
    @Excel(name = "关系表：relation的id")
    private Long relationId;

    /** 与户主关系 */
    @Excel(name = "与户主关系")
    private String relationTo;

    /** 国籍 */
    @Excel(name = "国籍")
    private String nationality;

    /** 民族 */
    @Excel(name = "民族")
    private String ethnicity;

    /** 文化程度 */
    @Excel(name = "文化程度")
    private String education;

    /** 职业 */
    @Excel(name = "职业")
    private String occupation;

    /** 证件类型：身份证 */
    @Excel(name = "证件类型：身份证")
    private String cardType;

    /** 证件号码 */
    @Excel(name = "证件号码")
    private String cardId;

    /** $column.columnComment */
    @Excel(name = "证件号码")
    private String homeTel;

    /** 本人电话 */
    @Excel(name = "本人电话")
    private String mobile;

    /** 医保类型 */
    @Excel(name = "医保类型")
    private String medicareType;

    /** 户籍性质（农/非农：和家庭签约表上面一样） */
    @Excel(name = "户籍性质", readConverterExp = "农=/非农：和家庭签约表上面一样")
    private String residenceType;

    /** 是否健在0是，1去世了 */
    @Excel(name = "是否健在0是，1去世了")
    private String liveStatus;

    /** $column.columnComment */
    @Excel(name = "是否健在0是，1去世了")
    private String photo;

    /** 用户签名 */
    @Excel(name = "用户签名")
    private String qianming;

    /** 健康状态 */
    @Excel(name = "健康状态")
    private String health;

    /** 身体状态-其他 */
    @Excel(name = "身体状态-其他")
    private String healthOther;

    /** 家庭成员临时编号 */
    @Excel(name = "家庭成员临时编号")
    private String memberSn;

    /** 0正常，1已经删除 */
    @Excel(name = "0正常，1已经删除")
    private Integer closed;

    /** 0普通家庭成员，1户主 */
    @Excel(name = "0普通家庭成员，1户主")
    private Integer isMain;

    /** 1，学生    2,社会 */
    @Excel(name = "1，学生    2,社会")
    private Integer isStudent;

    /** 0等待签约，-1，签约过期，1签约服务中 */
    @Excel(name = "0等待签约，-1，签约过期，1签约服务中")
    private Integer signingStatus;

    /** 服务开始时间 */
    @Excel(name = "服务开始时间")
    private Long serviceStartTime;

    /** 签约服务结束时间 */
    @Excel(name = "签约服务结束时间")
    private Long serviceEndTime;

    /** 下次履约服务时间 */
    @Excel(name = "下次履约服务时间")
    private Long nextServiceTime;

    /** 血型：A型，B型，O型，AB型，不详，RH阴性，RH阳性，RH不详 */
    @Excel(name = "血型：A型，B型，O型，AB型，不详，RH阴性，RH阳性，RH不详")
    private Integer bloodType;

    /** 职业 */
    @Excel(name = "职业")
    private String company;

    /** 包虫病：0疑似，1确诊，2不是 */
    @Excel(name = "包虫病：0疑似，1确诊，2不是")
    private Integer dBao;

    /** 高血压：0疑似，1确诊，2不是 */
    @Excel(name = "高血压：0疑似，1确诊，2不是")
    private Integer dGao;

    /** 糖尿病：0疑似，1确诊，2不是 */
    @Excel(name = "糖尿病：0疑似，1确诊，2不是")
    private Integer dTang;

    /** 乙肝：0疑似，1确诊，2不是 */
    @Excel(name = "乙肝：0疑似，1确诊，2不是")
    private Integer dYi;

    /** 结核病：0疑似，1确诊，2不是 */
    @Excel(name = "结核病：0疑似，1确诊，2不是")
    private Integer dJie;

    /** 严重精神障碍：0疑似，1确诊，2不是 */
    @Excel(name = "严重精神障碍：0疑似，1确诊，2不是")
    private Integer dJing;

    /** 慢性阻塞肺炎：0疑似，1确诊，2不是 */
    @Excel(name = "慢性阻塞肺炎：0疑似，1确诊，2不是")
    private Integer dFei;

    /** 大骨病：0疑似，1确诊，2不是 */
    @Excel(name = "大骨病：0疑似，1确诊，2不是")
    private Integer dDa;

    /** 类风湿性关节炎：0疑似，1确诊，2不是 */
    @Excel(name = "类风湿性关节炎：0疑似，1确诊，2不是")
    private Integer dLei;

    /** 恶性肿瘤：0疑似，1确诊，2不是 */
    @Excel(name = "恶性肿瘤：0疑似，1确诊，2不是")
    private Integer dZhong;

    /** 传染病：0疑似，1确诊，2不是 */
    @Excel(name = "传染病：0疑似，1确诊，2不是")
    private Integer dChuan;

    /** 先天性心脏病：0疑似，1确诊，2不是 */
    @Excel(name = "先天性心脏病：0疑似，1确诊，2不是")
    private Integer dXin;

    /** 肺结核：0疑似，1确诊，2不是 */
    @Excel(name = "肺结核：0疑似，1确诊，2不是")
    private Integer dJiehe;

    /** 地方病：0疑似，1确诊，2不是 */
    @Excel(name = "地方病：0疑似，1确诊，2不是")
    private Integer dDifang;

    /** 1新生儿，2：23-36个月幼儿，3：4-6岁儿童，4：6-15岁，5：65岁以上老人；6孕产妇 */
    @Excel(name = "1新生儿，2：23-36个月幼儿，3：4-6岁儿童，4：6-15岁，5：65岁以上老人；6孕产妇")
    private Integer isKeygroups;

    /** 二维码 */
    @Excel(name = "二维码")
    private String qrCode;

    public void setFamilyId(Integer familyId) 
    {
        this.familyId = familyId;
    }

    public Integer getFamilyId() 
    {
        return familyId;
    }
    public void setHouseholdNum(String householdNum) 
    {
        this.householdNum = householdNum;
    }

    public String getHouseholdNum() 
    {
        return householdNum;
    }
    public void setUserId(Long userId) 
    {
        this.userId = userId;
    }

    public Long getUserId() 
    {
        return userId;
    }
    public void setFamilySn(String familySn) 
    {
        this.familySn = familySn;
    }

    public String getFamilySn() 
    {
        return familySn;
    }
    public void setFamilyHealthNum(String familyHealthNum) 
    {
        this.familyHealthNum = familyHealthNum;
    }

    public String getFamilyHealthNum() 
    {
        return familyHealthNum;
    }
    public void setPersonalHealthNum(String personalHealthNum) 
    {
        this.personalHealthNum = personalHealthNum;
    }

    public String getPersonalHealthNum() 
    {
        return personalHealthNum;
    }
    public void setFamilyType(String familyType) 
    {
        this.familyType = familyType;
    }

    public String getFamilyType() 
    {
        return familyType;
    }
    public void setLiveType(String liveType) 
    {
        this.liveType = liveType;
    }

    public String getLiveType() 
    {
        return liveType;
    }
    public void setFamilyAddr(String familyAddr) 
    {
        this.familyAddr = familyAddr;
    }

    public String getFamilyAddr() 
    {
        return familyAddr;
    }
    public void setPersentAddr(String persentAddr) 
    {
        this.persentAddr = persentAddr;
    }

    public String getPersentAddr() 
    {
        return persentAddr;
    }
    public void setSigningId(Long signingId) 
    {
        this.signingId = signingId;
    }

    public Long getSigningId() 
    {
        return signingId;
    }
    public void setShopId(Long shopId) 
    {
        this.shopId = shopId;
    }

    public Long getShopId() 
    {
        return shopId;
    }
    public void setTeamId(Long teamId) 
    {
        this.teamId = teamId;
    }

    public Long getTeamId() 
    {
        return teamId;
    }
    public void setWorkerId(Long workerId) 
    {
        this.workerId = workerId;
    }

    public Long getWorkerId() 
    {
        return workerId;
    }
    public void setDoctorName(String doctorName) 
    {
        this.doctorName = doctorName;
    }

    public String getDoctorName() 
    {
        return doctorName;
    }
    public void setVillageName(String villageName) 
    {
        this.villageName = villageName;
    }

    public String getVillageName() 
    {
        return villageName;
    }
    public void setVillageId(Long villageId) 
    {
        this.villageId = villageId;
    }

    public Long getVillageId() 
    {
        return villageId;
    }
    public void setStreetName(String streetName) 
    {
        this.streetName = streetName;
    }

    public String getStreetName() 
    {
        return streetName;
    }
    public void setStreetId(Long streetId) 
    {
        this.streetId = streetId;
    }

    public Long getStreetId() 
    {
        return streetId;
    }
    public void setAreaName(String areaName) 
    {
        this.areaName = areaName;
    }

    public String getAreaName() 
    {
        return areaName;
    }
    public void setAreaId(Long areaId) 
    {
        this.areaId = areaId;
    }

    public Long getAreaId() 
    {
        return areaId;
    }
    public void setCityName(String cityName) 
    {
        this.cityName = cityName;
    }

    public String getCityName() 
    {
        return cityName;
    }
    public void setCityId(Long cityId) 
    {
        this.cityId = cityId;
    }

    public Long getCityId() 
    {
        return cityId;
    }
    public void setProvinceName(String provinceName) 
    {
        this.provinceName = provinceName;
    }

    public String getProvinceName() 
    {
        return provinceName;
    }
    public void setProvinceId(Long provinceId) 
    {
        this.provinceId = provinceId;
    }

    public Long getProvinceId() 
    {
        return provinceId;
    }
    public void setCountrysideId(Long countrysideId) 
    {
        this.countrysideId = countrysideId;
    }

    public Long getCountrysideId() 
    {
        return countrysideId;
    }
    public void setCountrysideName(String countrysideName) 
    {
        this.countrysideName = countrysideName;
    }

    public String getCountrysideName() 
    {
        return countrysideName;
    }
    public void setFamilyDoctorRoleId(Long familyDoctorRoleId) 
    {
        this.familyDoctorRoleId = familyDoctorRoleId;
    }

    public Long getFamilyDoctorRoleId() 
    {
        return familyDoctorRoleId;
    }
    public void setFamilyDoctorRoleName(String familyDoctorRoleName) 
    {
        this.familyDoctorRoleName = familyDoctorRoleName;
    }

    public String getFamilyDoctorRoleName() 
    {
        return familyDoctorRoleName;
    }
    public void setFamilyDoctorId(Long familyDoctorId) 
    {
        this.familyDoctorId = familyDoctorId;
    }

    public Long getFamilyDoctorId() 
    {
        return familyDoctorId;
    }
    public void setFamilyDoctorName(String familyDoctorName) 
    {
        this.familyDoctorName = familyDoctorName;
    }

    public String getFamilyDoctorName() 
    {
        return familyDoctorName;
    }
    public void setCountrysideDoctorRoleId(Long countrysideDoctorRoleId) 
    {
        this.countrysideDoctorRoleId = countrysideDoctorRoleId;
    }

    public Long getCountrysideDoctorRoleId() 
    {
        return countrysideDoctorRoleId;
    }
    public void setCountrysideDoctorRoleName(String countrysideDoctorRoleName) 
    {
        this.countrysideDoctorRoleName = countrysideDoctorRoleName;
    }

    public String getCountrysideDoctorRoleName() 
    {
        return countrysideDoctorRoleName;
    }
    public void setCountrysideDoctorId(Long countrysideDoctorId) 
    {
        this.countrysideDoctorId = countrysideDoctorId;
    }

    public Long getCountrysideDoctorId() 
    {
        return countrysideDoctorId;
    }
    public void setCountrysideDoctorName(String countrysideDoctorName) 
    {
        this.countrysideDoctorName = countrysideDoctorName;
    }

    public String getCountrysideDoctorName() 
    {
        return countrysideDoctorName;
    }
    public void setHeaderName(String headerName) 
    {
        this.headerName = headerName;
    }

    public String getHeaderName() 
    {
        return headerName;
    }
    public void setUserName(String userName) 
    {
        this.userName = userName;
    }

    public String getUserName() 
    {
        return userName;
    }
    public void setSex(String sex) 
    {
        this.sex = sex;
    }

    public String getSex() 
    {
        return sex;
    }
    public void setAge(Long age) 
    {
        this.age = age;
    }

    public Long getAge() 
    {
        return age;
    }
    public void setBirthday(String birthday) 
    {
        this.birthday = birthday;
    }

    public String getBirthday() 
    {
        return birthday;
    }
    public void setMedicalPaytype(String medicalPaytype) 
    {
        this.medicalPaytype = medicalPaytype;
    }

    public String getMedicalPaytype() 
    {
        return medicalPaytype;
    }
    public void setMaritalStatus(String maritalStatus) 
    {
        this.maritalStatus = maritalStatus;
    }

    public String getMaritalStatus() 
    {
        return maritalStatus;
    }
    public void setRelationId(Long relationId) 
    {
        this.relationId = relationId;
    }

    public Long getRelationId() 
    {
        return relationId;
    }
    public void setRelationTo(String relationTo) 
    {
        this.relationTo = relationTo;
    }

    public String getRelationTo() 
    {
        return relationTo;
    }
    public void setNationality(String nationality) 
    {
        this.nationality = nationality;
    }

    public String getNationality() 
    {
        return nationality;
    }
    public void setEthnicity(String ethnicity) 
    {
        this.ethnicity = ethnicity;
    }

    public String getEthnicity() 
    {
        return ethnicity;
    }
    public void setEducation(String education) 
    {
        this.education = education;
    }

    public String getEducation() 
    {
        return education;
    }
    public void setOccupation(String occupation) 
    {
        this.occupation = occupation;
    }

    public String getOccupation() 
    {
        return occupation;
    }
    public void setCardType(String cardType) 
    {
        this.cardType = cardType;
    }

    public String getCardType() 
    {
        return cardType;
    }
    public void setCardId(String cardId) 
    {
        this.cardId = cardId;
    }

    public String getCardId() 
    {
        return cardId;
    }
    public void setHomeTel(String homeTel) 
    {
        this.homeTel = homeTel;
    }

    public String getHomeTel() 
    {
        return homeTel;
    }
    public void setMobile(String mobile) 
    {
        this.mobile = mobile;
    }

    public String getMobile() 
    {
        return mobile;
    }
    public void setMedicareType(String medicareType) 
    {
        this.medicareType = medicareType;
    }

    public String getMedicareType() 
    {
        return medicareType;
    }
    public void setResidenceType(String residenceType) 
    {
        this.residenceType = residenceType;
    }

    public String getResidenceType() 
    {
        return residenceType;
    }
    public void setLiveStatus(String liveStatus) 
    {
        this.liveStatus = liveStatus;
    }

    public String getLiveStatus() 
    {
        return liveStatus;
    }
    public void setPhoto(String photo) 
    {
        this.photo = photo;
    }

    public String getPhoto() 
    {
        return photo;
    }
    public void setQianming(String qianming) 
    {
        this.qianming = qianming;
    }

    public String getQianming() 
    {
        return qianming;
    }
    public void setHealth(String health) 
    {
        this.health = health;
    }

    public String getHealth() 
    {
        return health;
    }
    public void setHealthOther(String healthOther) 
    {
        this.healthOther = healthOther;
    }

    public String getHealthOther() 
    {
        return healthOther;
    }
    public void setMemberSn(String memberSn) 
    {
        this.memberSn = memberSn;
    }

    public String getMemberSn() 
    {
        return memberSn;
    }
    public void setClosed(Integer closed) 
    {
        this.closed = closed;
    }

    public Integer getClosed() 
    {
        return closed;
    }
    public void setIsMain(Integer isMain) 
    {
        this.isMain = isMain;
    }

    public Integer getIsMain() 
    {
        return isMain;
    }
    public void setIsStudent(Integer isStudent) 
    {
        this.isStudent = isStudent;
    }

    public Integer getIsStudent() 
    {
        return isStudent;
    }
    public void setSigningStatus(Integer signingStatus) 
    {
        this.signingStatus = signingStatus;
    }

    public Integer getSigningStatus() 
    {
        return signingStatus;
    }
    public void setServiceStartTime(Long serviceStartTime) 
    {
        this.serviceStartTime = serviceStartTime;
    }

    public Long getServiceStartTime() 
    {
        return serviceStartTime;
    }
    public void setServiceEndTime(Long serviceEndTime) 
    {
        this.serviceEndTime = serviceEndTime;
    }

    public Long getServiceEndTime() 
    {
        return serviceEndTime;
    }
    public void setNextServiceTime(Long nextServiceTime) 
    {
        this.nextServiceTime = nextServiceTime;
    }

    public Long getNextServiceTime() 
    {
        return nextServiceTime;
    }
    public void setBloodType(Integer bloodType) 
    {
        this.bloodType = bloodType;
    }

    public Integer getBloodType() 
    {
        return bloodType;
    }
    public void setCompany(String company) 
    {
        this.company = company;
    }

    public String getCompany() 
    {
        return company;
    }
    public void setdBao(Integer dBao) 
    {
        this.dBao = dBao;
    }

    public Integer getdBao() 
    {
        return dBao;
    }
    public void setdGao(Integer dGao) 
    {
        this.dGao = dGao;
    }

    public Integer getdGao() 
    {
        return dGao;
    }
    public void setdTang(Integer dTang) 
    {
        this.dTang = dTang;
    }

    public Integer getdTang() 
    {
        return dTang;
    }
    public void setdYi(Integer dYi) 
    {
        this.dYi = dYi;
    }

    public Integer getdYi() 
    {
        return dYi;
    }
    public void setdJie(Integer dJie) 
    {
        this.dJie = dJie;
    }

    public Integer getdJie() 
    {
        return dJie;
    }
    public void setdJing(Integer dJing) 
    {
        this.dJing = dJing;
    }

    public Integer getdJing() 
    {
        return dJing;
    }
    public void setdFei(Integer dFei) 
    {
        this.dFei = dFei;
    }

    public Integer getdFei() 
    {
        return dFei;
    }
    public void setdDa(Integer dDa) 
    {
        this.dDa = dDa;
    }

    public Integer getdDa() 
    {
        return dDa;
    }
    public void setdLei(Integer dLei) 
    {
        this.dLei = dLei;
    }

    public Integer getdLei() 
    {
        return dLei;
    }
    public void setdZhong(Integer dZhong) 
    {
        this.dZhong = dZhong;
    }

    public Integer getdZhong() 
    {
        return dZhong;
    }
    public void setdChuan(Integer dChuan) 
    {
        this.dChuan = dChuan;
    }

    public Integer getdChuan() 
    {
        return dChuan;
    }
    public void setdXin(Integer dXin) 
    {
        this.dXin = dXin;
    }

    public Integer getdXin() 
    {
        return dXin;
    }
    public void setdJiehe(Integer dJiehe) 
    {
        this.dJiehe = dJiehe;
    }

    public Integer getdJiehe() 
    {
        return dJiehe;
    }
    public void setdDifang(Integer dDifang) 
    {
        this.dDifang = dDifang;
    }

    public Integer getdDifang() 
    {
        return dDifang;
    }
    public void setIsKeygroups(Integer isKeygroups) 
    {
        this.isKeygroups = isKeygroups;
    }

    public Integer getIsKeygroups() 
    {
        return isKeygroups;
    }
    public void setQrCode(String qrCode) 
    {
        this.qrCode = qrCode;
    }

    public String getQrCode() 
    {
        return qrCode;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("familyId", getFamilyId())
            .append("householdNum", getHouseholdNum())
            .append("userId", getUserId())
            .append("familySn", getFamilySn())
            .append("familyHealthNum", getFamilyHealthNum())
            .append("personalHealthNum", getPersonalHealthNum())
            .append("familyType", getFamilyType())
            .append("liveType", getLiveType())
            .append("familyAddr", getFamilyAddr())
            .append("persentAddr", getPersentAddr())
            .append("signingId", getSigningId())
            .append("shopId", getShopId())
            .append("teamId", getTeamId())
            .append("workerId", getWorkerId())
            .append("doctorName", getDoctorName())
            .append("villageName", getVillageName())
            .append("villageId", getVillageId())
            .append("streetName", getStreetName())
            .append("streetId", getStreetId())
            .append("areaName", getAreaName())
            .append("areaId", getAreaId())
            .append("cityName", getCityName())
            .append("cityId", getCityId())
            .append("provinceName", getProvinceName())
            .append("provinceId", getProvinceId())
            .append("countrysideId", getCountrysideId())
            .append("countrysideName", getCountrysideName())
            .append("familyDoctorRoleId", getFamilyDoctorRoleId())
            .append("familyDoctorRoleName", getFamilyDoctorRoleName())
            .append("familyDoctorId", getFamilyDoctorId())
            .append("familyDoctorName", getFamilyDoctorName())
            .append("countrysideDoctorRoleId", getCountrysideDoctorRoleId())
            .append("countrysideDoctorRoleName", getCountrysideDoctorRoleName())
            .append("countrysideDoctorId", getCountrysideDoctorId())
            .append("countrysideDoctorName", getCountrysideDoctorName())
            .append("headerName", getHeaderName())
            .append("userName", getUserName())
            .append("sex", getSex())
            .append("age", getAge())
            .append("birthday", getBirthday())
            .append("medicalPaytype", getMedicalPaytype())
            .append("maritalStatus", getMaritalStatus())
            .append("relationId", getRelationId())
            .append("relationTo", getRelationTo())
            .append("nationality", getNationality())
            .append("ethnicity", getEthnicity())
            .append("education", getEducation())
            .append("occupation", getOccupation())
            .append("cardType", getCardType())
            .append("cardId", getCardId())
            .append("homeTel", getHomeTel())
            .append("mobile", getMobile())
            .append("medicareType", getMedicareType())
            .append("residenceType", getResidenceType())
            .append("liveStatus", getLiveStatus())
            .append("photo", getPhoto())
            .append("qianming", getQianming())
            .append("health", getHealth())
            .append("healthOther", getHealthOther())
            .append("memberSn", getMemberSn())
            .append("closed", getClosed())
            .append("isMain", getIsMain())
            .append("createTime", getCreateTime())
            .append("isStudent", getIsStudent())
            .append("signingStatus", getSigningStatus())
            .append("serviceStartTime", getServiceStartTime())
            .append("serviceEndTime", getServiceEndTime())
            .append("nextServiceTime", getNextServiceTime())
            .append("bloodType", getBloodType())
            .append("company", getCompany())
            .append("dBao", getdBao())
            .append("dGao", getdGao())
            .append("dTang", getdTang())
            .append("dYi", getdYi())
            .append("dJie", getdJie())
            .append("dJing", getdJing())
            .append("dFei", getdFei())
            .append("dDa", getdDa())
            .append("dLei", getdLei())
            .append("dZhong", getdZhong())
            .append("dChuan", getdChuan())
            .append("dXin", getdXin())
            .append("dJiehe", getdJiehe())
            .append("dDifang", getdDifang())
            .append("isKeygroups", getIsKeygroups())
            .append("qrCode", getQrCode())
            .toString();
    }
}
